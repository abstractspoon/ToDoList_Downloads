// FMindExporter.cpp: implementation of the CFMindExporter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FMindImportExport.h"
#include "FMindExporter.h"

#include "..\shared\xmlfileex.h"
#include "..\todolist\tdlschemadef.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFMindExporter::CFMindExporter()
{

}

CFMindExporter::~CFMindExporter()
{

}

bool CFMindExporter::Export(const ITaskList* pSrcTaskFile, const char* szDestFilePath)
{
	CXmlFile fileDest("map");
	//fileDest.EnableFormattedOutput(TRUE);	

	CXmlItem *firstItem = fileDest.Root()->AddItem("node","");


	firstItem->AddItem("TEXT",pSrcTaskFile->GetProjectName());	
	CXmlItem * hookItem = firstItem->AddItem("hook","");
	hookItem->AddItem("NAME","accessories/plugins/AutomaticLayout.properties");

	//Attrib Manager settings
	//This will make the attribs not to be shown as a list view at every node;	
	CXmlItem *attribManItem = firstItem->AddItem("attribute_registry","");	
	attribManItem->AddItem("SHOW_ATTRIBUTES","hide");

	// export first task
	ExportTask((ITaskList7*)pSrcTaskFile, pSrcTaskFile->GetFirstTask(), firstItem , 0);

	// save result
	VERIFY (fileDest.Save(szDestFilePath));



	return true;
}

void CFMindExporter::ExportTask(const ITaskList7* pSrcTaskFile, HTASKITEM hTask, CXmlItem* pXIDestParent , int LEVEL)
{
	if (!hTask)
		return;

	char cTemp;

	// create a new item corresponding to pXITask at the dest
	CXmlItem* pXIDestItem = pXIDestParent->AddItem("node");

	// copy across the appropriate attributes
	//pXIDestItem->AddItem("id", (int)pSrcTaskFile->GetTaskID(hTask));
	pXIDestItem->AddItem("TEXT", pSrcTaskFile->GetTaskTitle(hTask));

	CString sModified;
	sModified.Format("%i",pSrcTaskFile->GetTaskLastModified(hTask) * 1000);
	pXIDestItem->AddItem("MODIFIED",sModified);
	int nTaskPrior = pSrcTaskFile->GetTaskPriority(hTask,FALSE);
	time_t tDone = pSrcTaskFile->GetTaskDoneDate(hTask);
	
	if (tDone)
	{		
		CXmlItem* pXIIcons = pXIDestItem->AddItem("icon");
		pXIIcons->AddItem("BUILTIN","button_ok");
	}

	if (nTaskPrior !=0)
	{		
		CString sIconName;
		sIconName.Format("full-%d",nTaskPrior);		
		CXmlItem* pXIIcons = pXIDestItem->AddItem("icon");
		pXIIcons->AddItem("BUILTIN",sIconName);
	}
	
	// comments
	CXmlItem* pXIAttribs; 
	CString sComments = pSrcTaskFile->GetTaskComments(hTask);
	
	if (!sComments.IsEmpty())
	{
		// for version 0.9 we export comments as rich NOTE
		CXmlItem* pXIComments = pXIDestItem->AddItem("richcontent", sComments);
		pXIComments->AddItem("TYPE", "NOTE");
		
		// for version 0.8 we export comments as private attribute
		pXIAttribs= pXIDestItem->AddItem("attribute");
		pXIAttribs->AddItem("NAME","Comments");
		pXIAttribs->AddItem("VALUE",sComments);
	}
	
	//Start of Attrib List not Supported by FreeMind
	/*
	//fixme: Check how to use the resources and their index for the following 
	//functions
	//virtual bool SetTaskAllocatedTo(HTASKITEM hTask, const char* szAllocTo) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","AllocatedTo");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskAllocatedTo(hTask));

	//virtual bool SetTaskAllocatedBy(HTASKITEM hTask, const char* szAllocBy) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskAllocatedBy");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskAllocatedBy(hTask));


	//virtual bool SetTaskCategory(HTASKITEM hTask, const char* szCategory) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskCategory");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskCategory(hTask));

	//virtual bool SetTaskDependency(HTASKITEM hTask, const char* szDepends) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskDependency");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskDependency(hTask));

	*/

	//virtual bool SetTaskStatus(HTASKITEM hTask, const char* szStatus) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskStatus");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskStatus(hTask));


	//virtual bool SetTaskFileReferencePath(HTASKITEM hTask, const char* szFileRefpath) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskFileReferencePath");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskFileReferencePath(hTask));
	
	//virtual bool SetTaskColor(HTASKITEM hTask, unsigned long nColor) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskColor");
	pXIAttribs->AddItem("VALUE",(double)pSrcTaskFile->GetTaskColor(hTask));

	
	//Already Added
	//virtual bool SetTaskPriority(HTASKITEM hTask, unsigned char nPriority) = 0;
	//pXIAttribs= pXIDestItem->AddItem("attribute");
	//pXIAttribs->AddItem("NAME","TaskPriority");
	//pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskPriority(hTask,FALSE));


	//virtual bool SetTaskPercentDone(HTASKITEM hTask, unsigned char nPercent) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskPercentDone");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskPercentDone(hTask,FALSE));

	//virtual bool SetTaskTimeEstimate(HTASKITEM hTask, double dTimeEst, char cUnits) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskTimeEstimate");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskTimeEstimate(hTask,cTemp,FALSE));

	//virtual bool SetTaskTimeSpent(HTASKITEM hTask, double dTimeSpent, char cUnits) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskTimeSpent");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskTimeSpent(hTask,cTemp,FALSE));
	
	//Already Added
	//virtual bool SetTaskDoneDate(HTASKITEM hTask, time_t tDoneDate) = 0;
	//pXIAttribs= pXIDestItem->AddItem("attribute");
	//pXIAttribs->AddItem("NAME","TaskDoneDate");
	//pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskDoneDate(hTask));

	//virtual bool SetTaskDueDate(HTASKITEM hTask, time_t tDueDate) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskDueDate");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskDueDate(hTask,FALSE));

	//virtual bool SetTaskStartDate(HTASKITEM hTask, time_t tStartDate) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskStartDate");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskStartDate(hTask));
	
	//virtual bool SetTaskPosition(HTASKITEM hTask, unsigned long nPos) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskPosition");
	pXIAttribs->AddItem("VALUE",(int)pSrcTaskFile->GetTaskPosition(hTask));
	
	//virtual bool SetTaskFlag(HTASKITEM hTask, bool bFlag) = 0;
	
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskFlag");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->IsTaskFlagged(hTask));

	//virtual bool SetTaskCreatedBy(HTASKITEM hTask, const char* szCreatedBy) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskCreatedBy");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskCreatedBy(hTask));


	//virtual bool SetTaskCreationDate(HTASKITEM hTask, time_t tCreationDate) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskCreationDate");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskCreationDate(hTask));


	//virtual bool SetTaskRisk(HTASKITEM hTask, unsigned char nRisk) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskRisk");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskRisk(hTask,FALSE));


	//virtual bool SetTaskExternalID(HTASKITEM hTask, const char* szID) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskExternalID");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskExternalID(hTask));

	//virtual bool SetTaskCost(HTASKITEM hTask, double dCost) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskCost");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskCost(hTask,FALSE));

	//virtual bool SetTaskRecurrence(HTASKITEM hTask, int& nRegularity, DWORD& dwSpecific1, 
	//								DWORD& dwSpecific2, BOOL& bRecalcFromDue) const = 0;
	int nRegularity;
	DWORD dwSpecific1, dwSpecific2;
	BOOL bRecalcFromDue;
	
	pSrcTaskFile->GetTaskRecurrence(hTask, nRegularity, dwSpecific1, dwSpecific2, bRecalcFromDue);

	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","nRegularity");
	pXIAttribs->AddItem("VALUE",nRegularity);
	
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","dwSpecific1");
	pXIAttribs->AddItem("VALUE",(int)dwSpecific1);

	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","dwSpecific2");
	pXIAttribs->AddItem("VALUE",(int)dwSpecific2);

	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","bRecalcFromDue");
	pXIAttribs->AddItem("VALUE",bRecalcFromDue);

	//virtual bool SetTaskVersion(HTASKITEM hTask, const char* szVersion) = 0;
	pXIAttribs= pXIDestItem->AddItem("attribute");
	pXIAttribs->AddItem("NAME","TaskVersion");
	pXIAttribs->AddItem("VALUE",pSrcTaskFile->GetTaskVersion(hTask));
	
	//End of Attrib List not Supported by FreeMind

	static bool bRight = true;
	if (LEVEL == 0)
	{
		if (bRight)
			pXIDestItem->AddItem("POSITION","right");
		else
			pXIDestItem->AddItem("POSITION","left");
		bRight = ! bRight; 
	}

	// copy across first child
	ExportTask(pSrcTaskFile, pSrcTaskFile->GetFirstTask(hTask), pXIDestItem , LEVEL + 1);

	// copy across first sibling
	ExportTask(pSrcTaskFile, pSrcTaskFile->GetNextTask(hTask), pXIDestParent , LEVEL);
}
