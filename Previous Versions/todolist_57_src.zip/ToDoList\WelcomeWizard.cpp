// WelcomeWizard.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "WelcomeWizard.h"
#include "..\shared\dialoghelper.h"
#include "..\shared\misc.h"
#include "..\shared\filemisc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWelcomeWizard

IMPLEMENT_DYNAMIC(CWelcomeWizard, CPropertySheet)

CWelcomeWizard::CWelcomeWizard() : CPropertySheet("", NULL, 0)
{
	InitSheet();
}

void CWelcomeWizard::InitSheet()
{
	m_hFont = Misc::CreateFont("Tahoma");

	m_page1.AttachFont(m_hFont);
	m_page2.AttachFont(m_hFont);
	m_page3.AttachFont(m_hFont);

	AddPage(&m_page1);
	AddPage(&m_page2);
	AddPage(&m_page3);
	SetWizardMode();

	m_psh.dwFlags &= ~(PSH_HASHELP);		
}

CWelcomeWizard::~CWelcomeWizard()
{
}


BEGIN_MESSAGE_MAP(CWelcomeWizard, CPropertySheet)
	//{{AFX_MSG_MAP(CWelcomeWizard)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_WIZFINISH, OnWizFinish)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWelcomeWizard message handlers

BOOL CWelcomeWizard::OnInitDialog() 
{
	CPropertySheet::OnInitDialog();

	CDialogHelper::SetFont(this, m_hFont);

	HICON hIcon = AfxGetApp()->LoadIcon(IDI_TRAYICONXP);
	SetIcon(hIcon, FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CWelcomeWizard::OnWizFinish()
{	
	m_page1.UpdateData();
	m_page2.UpdateData();
	m_page3.UpdateData();

	EndDialog(ID_WIZFINISH);
}

/////////////////////////////////////////////////////////////////////////////
// CWelcomePage1 property page

IMPLEMENT_DYNCREATE(CWelcomePage1, CPropertyPage)

CWelcomePage1::CWelcomePage1() : CPropertyPage(CWelcomePage1::IDD)
{
	//{{AFX_DATA_INIT(CWelcomePage1)
	m_bShareTasklists = 1;
	m_bUseIniFile = 1;
	//}}AFX_DATA_INIT
	m_psp.dwFlags &= ~(PSP_HASHELP);		
}

CWelcomePage1::~CWelcomePage1()
{
}

void CWelcomePage1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWelcomePage1)
	DDX_Radio(pDX, IDC_NOSHARE, m_bShareTasklists);
	DDX_Radio(pDX, IDC_REGISTRY, m_bUseIniFile);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWelcomePage1, CPropertyPage)
	//{{AFX_MSG_MAP(CWelcomePage1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWelcomePage1 message handlers

BOOL CWelcomePage1::OnInitDialog() 
{
	CDialogHelper::SetFont(this, m_hFont);
	CPropertyPage::OnInitDialog();
		
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////
// CWelcomePage2 property page

IMPLEMENT_DYNCREATE(CWelcomePage2, CPropertyPage)

CWelcomePage2::CWelcomePage2() : CPropertyPage(CWelcomePage2::IDD)
{
	//{{AFX_DATA_INIT(CWelcomePage2)
	//}}AFX_DATA_INIT
	m_psp.dwFlags &= ~(PSP_HASHELP);		
}

CWelcomePage2::~CWelcomePage2()
{
}

void CWelcomePage2::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWelcomePage2)
	DDX_Control(pDX, IDC_COLUMNLIST, m_lbColumns);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWelcomePage2, CPropertyPage)
	//{{AFX_MSG_MAP(CWelcomePage2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWelcomePage2 message handlers

BOOL CWelcomePage2::OnInitDialog() 
{
	CDialogHelper::SetFont(this, m_hFont);
	CPropertyPage::OnInitDialog();

	// initialize the visible columns for first time users
	m_lbColumns.SetAllColumnsVisible(FALSE);
	m_lbColumns.SetColumnVisible(TDCC_PRIORITY);
	m_lbColumns.SetColumnVisible(TDCC_PERCENT);
	m_lbColumns.SetColumnVisible(TDCC_ALLOCTO);
	m_lbColumns.SetColumnVisible(TDCC_TIMEEST);
	m_lbColumns.SetColumnVisible(TDCC_TIMESPENT);
	m_lbColumns.SetColumnVisible(TDCC_STATUS);
	m_lbColumns.SetColumnVisible(TDCC_CATEGORY);
	m_lbColumns.SetColumnVisible(TDCC_TRACKTIME);
	m_lbColumns.SetColumnVisible(TDCC_DUEDATE);
	m_lbColumns.SetColumnVisible(TDCC_FILEREF);
	m_lbColumns.SetColumnVisible(TDCC_DONE);
//	m_lbColumns.SetColumnVisible();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CWelcomePage2::OnSetActive() 
{
	((CPropertySheet*)GetParent())->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);
	
	return CPropertyPage::OnSetActive();
}

/////////////////////////////////////////////////////////////////////////////
// CWelcomePage3 property page

IMPLEMENT_DYNCREATE(CWelcomePage3, CPropertyPage)

CWelcomePage3::CWelcomePage3() : CPropertyPage(CWelcomePage3::IDD)
{
	//{{AFX_DATA_INIT(CWelcomePage3)
	m_bHideAttrib = 1;
	m_bViewSample = 1;
	//}}AFX_DATA_INIT
	CString sResFolder = FileMisc::GetModuleFolder() + "Resources";
	FileMisc::MakePath(m_sSampleTaskList, NULL, sResFolder, "Introduction.tdl");

	CString sFilter;
	sFilter.LoadString(IDS_TDLFILEFILTER);
	m_eSampleTasklist.SetFilter(sFilter);

	m_psp.dwFlags &= ~(PSP_HASHELP);		
}

CWelcomePage3::~CWelcomePage3()
{
}

void CWelcomePage3::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWelcomePage3)
	DDX_Control(pDX, IDC_SAMPLETASKLIST, m_eSampleTasklist);
	DDX_Text(pDX, IDC_SAMPLETASKLIST, m_sSampleTaskList);
	DDX_Radio(pDX, IDC_ALLOPTIONS, m_bHideAttrib);
	DDX_Radio(pDX, IDC_NOSAMPLE, m_bViewSample);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWelcomePage3, CPropertyPage)
	//{{AFX_MSG_MAP(CWelcomePage3)
	ON_BN_CLICKED(IDC_NOSAMPLE, OnNosample)
	ON_BN_CLICKED(IDC_SAMPLE, OnSample)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWelcomePage3 message handlers

BOOL CWelcomePage3::OnInitDialog() 
{
	CDialogHelper::SetFont(this, m_hFont);
	CPropertyPage::OnInitDialog();
	
	m_eSampleTasklist.SetButtonWidthDLU(1, 14);
	m_eSampleTasklist.EnableWindow(m_bViewSample);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CWelcomePage3::OnNosample() 
{
	UpdateData();
	m_eSampleTasklist.EnableWindow(m_bViewSample);
}

void CWelcomePage3::OnSample() 
{
	UpdateData();
	m_eSampleTasklist.EnableWindow(m_bViewSample);
}


BOOL CWelcomePage3::OnSetActive() 
{
	((CPropertySheet*)GetParent())->SetWizardButtons(PSWIZB_BACK | PSWIZB_FINISH);
	
	return CPropertyPage::OnSetActive();
}


