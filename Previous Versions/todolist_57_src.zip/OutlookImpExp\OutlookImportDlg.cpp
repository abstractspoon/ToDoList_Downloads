'/;// OutlookImportDlg.cpp : implementation file
//

#include "stdafx.h"
#include "OutlookImpExp.h"
#include "OutlookImportDlg.h"
#include "msoutl.h"

#include "..\shared\ITaskList.h"
#include "..\shared\misc.h"
#include <afxtempl.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


const int olFolderDeletedItems	= 3;
const int olFolderOutbox		= 4;
const int olFolderSentMail		= 5;
const int olFolderInbox			= 6;
const int olFolderCalendar		= 9;
const int olFolderContacts		= 10;
const int olFolderJournal		= 11;
const int olFolderNotes			= 12;
const int olFolderTasks			= 13;

/////////////////////////////////////////////////////////////////////////////
// COutlookImportDlg dialog


COutlookImportDlg::COutlookImportDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COutlookImportDlg::IDD, pParent), m_pDestTaskFile(NULL), m_pOutlook(NULL)
{
	//{{AFX_DATA_INIT(COutlookImportDlg)
	//}}AFX_DATA_INIT
	m_bRemoveOutlookTasks = AfxGetApp()->GetProfileInt("Importers\\Outlook", "RemoveOutlookTasks", FALSE);
}


void COutlookImportDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COutlookImportDlg)
	DDX_Control(pDX, IDC_TASKLIST, m_lbTasks);
	DDX_Check(pDX, IDC_REMOVEOUTLOOKTASKS, m_bRemoveOutlookTasks);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COutlookImportDlg, CDialog)
	//{{AFX_MSG_MAP(COutlookImportDlg)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COutlookImportDlg message handlers

BOOL COutlookImportDlg::ImportTasks(ITaskList* pDestTaskFile)
{
	m_pDestTaskFile = GetITLInterface<ITaskList7>(pDestTaskFile, IID_TASKLIST7);
	ASSERT(m_pDestTaskFile);

	if (!m_pDestTaskFile)
		return FALSE;

	return (DoModal() == IDOK);
}

BOOL COutlookImportDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	ASSERT(m_pOutlook == NULL);
	m_pOutlook = new _Application;

	if (m_pOutlook->CreateDispatch("Outlook.Application"))
	{
		_NameSpace nmspc(m_pOutlook->GetNamespace("MAPI"));
		
		MAPIFolder mapi(nmspc.GetDefaultFolder(olFolderTasks));

		_Items items(mapi.GetItems());
		int nCount = items.GetCount();

		for (int nItem = 1; nItem <= nCount; nItem++)
		{
			_TaskItem task(items.Item(COleVariant((short)nItem)));

			int nIndex = m_lbTasks.AddString(task.GetSubject());
			m_lbTasks.SetItemData(nIndex, nItem);
			m_lbTasks.SetCheck(nIndex, TRUE);
		}
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void COutlookImportDlg::OnOK()
{
	CDialog::OnOK();

	ASSERT(m_pOutlook && m_pDestTaskFile);

	// make sure nothing has changed
	_NameSpace nmspc(m_pOutlook->GetNamespace("MAPI"));
	MAPIFolder mapi(nmspc.GetDefaultFolder(olFolderTasks));
	_Items items(mapi.GetItems());

	int nTaskCount = items.GetCount();
	int nLBCount = m_lbTasks.GetCount();

	ASSERT (nLBCount == nTaskCount);

	// keep track of the indices of the imported tasks 
	// in case we need to remove them afterwards
	CArray<long, long> aTasks; 
	
	// iterate the listbox items looking for checked items
	for (int nItem = 0; nItem <= nLBCount; nItem++)
	{
		if (m_lbTasks.GetCheck(nItem))
		{
			// get the task index that this item points to
			int nTask = m_lbTasks.GetItemData(nItem);
			_TaskItem task(items.Item(COleVariant((short)nTask)));

			aTasks.Add(nTask);

			// check the task title has not changed
			CString sLBItem;
			m_lbTasks.GetText(nItem, sLBItem);
			ASSERT (sLBItem == task.GetSubject());

			// create a new task
			HTASKITEM hTask = m_pDestTaskFile->NewTask(sLBItem);
			ASSERT(hTask);

			// set it's attributes
			m_pDestTaskFile->SetTaskComments(hTask, task.GetBody());
			m_pDestTaskFile->SetTaskCategory(hTask, task.GetCategories());

			if (task.GetComplete())
				m_pDestTaskFile->SetTaskDoneDate(hTask, ConvertDate(task.GetDateCompleted()));

			m_pDestTaskFile->SetTaskDueDate(hTask, ConvertDate(task.GetDueDate()));
			m_pDestTaskFile->SetTaskStartDate(hTask, ConvertDate(task.GetStartDate()));
			m_pDestTaskFile->SetTaskCreationDate(hTask, ConvertDate(task.GetCreationTime()));
			m_pDestTaskFile->SetTaskLastModified(hTask, ConvertDate(task.GetLastModificationTime()));
			m_pDestTaskFile->SetTaskExternalID(hTask, task.GetEntryID());
			m_pDestTaskFile->SetTaskAllocatedBy(hTask, task.GetDelegator());
			m_pDestTaskFile->SetTaskAllocatedTo(hTask, task.GetOwner());
			m_pDestTaskFile->SetTaskPriority(hTask, (unsigned char)(task.GetImportance() * 5));
			
/*
			m_pDestTaskFile->SetTask(hTask, task.Get());
			m_pDestTaskFile->SetTask(hTask, task.Get());
			m_pDestTaskFile->SetTask(hTask, task.Get());
			m_pDestTaskFile->SetTask(hTask, task.Get());
			m_pDestTaskFile->SetTask(hTask, task.Get());
			m_pDestTaskFile->SetTask(hTask, task.Get());
			m_pDestTaskFile->SetTask(hTask, task.Get());
			m_pDestTaskFile->SetTask(hTask, task.Get());
			m_pDestTaskFile->SetTask(hTask, task.Get());
			m_pDestTaskFile->SetTask(hTask, task.Get());
			m_pDestTaskFile->SetTask(hTask, task.Get());
			m_pDestTaskFile->SetTask(hTask, task.Get());
*/
		}
	}

	if (m_bRemoveOutlookTasks && aTasks.GetSize())
	{
		qsort(aTasks.GetData(), aTasks.GetSize(), sizeof(long), SortProc);

		// delete tasks working from the end back
		int nTask = aTasks.GetSize();

		while (nTask--)
			items.Remove(aTasks[nTask]);
	}

	AfxGetApp()->WriteProfileInt("Importers\\Outlook", "RemoveOutlookTasks", m_bRemoveOutlookTasks);
}

int COutlookImportDlg::SortProc(const void* item1, const void* item2)
{
	long shItem1 = *((const long*)item1);
	long shItem2 = *((const long*)item2);

	if (shItem1 < shItem2)
		return -1;

	else if (shItem1 > shItem2)
		return 1;
	else
	{
		ASSERT(0);
		return 0;
	}
}

void COutlookImportDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	delete m_pOutlook;
	m_pOutlook = NULL;
	m_pDestTaskFile = NULL;
}

time_t COutlookImportDlg::ConvertDate(DATE date)
{
	if (date <= 0.0)
		return 0;

	SYSTEMTIME st;
	COleDateTime dt(date);

	dt.GetAsSystemTime(st);

	tm t = { st.wSecond, st.wMinute, st.wHour, st.wDay, st.wMonth - 1, st.wYear - 1900, 0 };
	return mktime(&t);
}
