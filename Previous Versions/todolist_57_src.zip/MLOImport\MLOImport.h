// MLOImport.h : main header file for the MLOIMPORT DLL
//

#if !defined(AFX_MLOIMPORT_H__9312B45D_E40F_4CD3_B90E_BF54C582CDBE__INCLUDED_)
#define AFX_MLOIMPORT_H__9312B45D_E40F_4CD3_B90E_BF54C582CDBE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMLOImportApp
// See MLOImport.cpp for the implementation of this class
//

class CMLOImportApp : public CWinApp 
{
public:
	CMLOImportApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMLOImportApp)
	//}}AFX_VIRTUAL
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MLOIMPORT_H__9312B45D_E40F_4CD3_B90E_BF54C582CDBE__INCLUDED_)
