// PreferencesPageBase.cpp : implementation file
//

#include "stdafx.h"
#include "PreferencesBase.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesPageBase property page

IMPLEMENT_DYNCREATE(CPreferencesPageBase, CPropertyPage)

CPreferencesPageBase::CPreferencesPageBase(UINT nID) : CPropertyPage(nID)
{
}

CPreferencesPageBase::~CPreferencesPageBase()
{
}

/////////////////////////////////////////////////////////////////////////////
// CPreferencesDlgBase dialog


CPreferencesDlgBase::CPreferencesDlgBase(UINT nID, CWnd* pParent) : CDialog(nID, pParent), m_nInitPage(-1)
{
}

BEGIN_MESSAGE_MAP(CPreferencesDlgBase, CDialog)
//{{AFX_MSG_MAP(CPreferencesDlg)
ON_WM_DESTROY()
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CPreferencesDlgBase::OnOK()
{
	CDialog::OnOK();
	
	m_pphost.OnOK();
	SavePreferences();
}

int CPreferencesDlgBase::DoModal(int nInitPage)
{
	if (nInitPage != -1)
		m_nInitPage = nInitPage;
	
	return CDialog::DoModal();
}

BOOL CPreferencesDlgBase::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CPreferencesDlgBase::CreatePPHost(UINT nHostID)
{
	if (GetDlgItem(nHostID))
	{
		CRect rPPHost;
		GetDlgItem(nHostID)->GetWindowRect(rPPHost);
		ScreenToClient(rPPHost);
		
		return CreatePPHost(rPPHost);
	}
	
	// else
	return FALSE;
}

BOOL CPreferencesDlgBase::CreatePPHost(LPRECT pRect)
{
	if (m_pphost.Create(pRect, this))
	{
		if (m_nInitPage > 0 && m_nInitPage < m_pphost.GetPageCount())
			return SetActivePage(m_nInitPage);
		
		// else
		return TRUE;
	}
	
	// else
	return FALSE;
}

BOOL CPreferencesDlgBase::SetActivePage(int nPage)
{
	CPropertyPage* pPage = m_pphost.GetPage(nPage);
	ASSERT (pPage);
	
	return m_pphost.SetActivePage(pPage);
}

BOOL CPreferencesDlgBase::SetActivePage(CPreferencesPageBase* pPage)
{
	if (pPage->IsKindOf(RUNTIME_CLASS(CPreferencesPageBase)))
		return m_pphost.SetActivePage(pPage);
	
	// else
	return FALSE;
}

BOOL CPreferencesDlgBase::AddPage(CPreferencesPageBase* pPage)
{
	if (pPage->IsKindOf(RUNTIME_CLASS(CPreferencesPageBase)))
		return m_pphost.AddPage(pPage);
	
	// else
	return FALSE;
}

void CPreferencesDlgBase::OnDestroy() 
{
	CDialog::OnDestroy();
}

void CPreferencesDlgBase::LoadPreferences()
{
	// new storage object
	CPreferences prefs;
	
	// cycle the page loading the preferences for each one
	int nPage = m_pphost.GetPageCount();
	
	while (nPage--)
	{
		CPreferencesPageBase* pPage = (CPreferencesPageBase*)m_pphost.GetPage(nPage);
		
		if (pPage->IsKindOf(RUNTIME_CLASS(CPreferencesPageBase)))
			pPage->LoadPreferences(prefs);
	}
	
	// initial page
	if (m_nInitPage < 0 || m_nInitPage >= m_pphost.GetPageCount())
		m_nInitPage = prefs.GetProfileInt("Preferences", "StartPage", 0);
}

void CPreferencesDlgBase::SavePreferences()
{
	// new storage object
	CPreferences prefs;
	
	// cycle the page saving the preferences for each one
	int nPage = m_pphost.GetPageCount();
	
	while (nPage--)
	{
		CPreferencesPageBase* pPage = (CPreferencesPageBase*)m_pphost.GetPage(nPage);
		
		if (pPage->IsKindOf(RUNTIME_CLASS(CPreferencesPageBase)))
			pPage->SavePreferences(prefs);
	}
	
	prefs.WriteProfileInt("Preferences", "StartPage", m_pphost.GetActiveIndex());
}


/////////////////////////////////////////////////////////////////////////////
