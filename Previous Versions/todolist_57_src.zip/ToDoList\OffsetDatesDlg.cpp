// OffsetDatesDlg.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "OffsetDatesDlg.h"

#include "..\shared\Preferences.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COffsetDatesDlg dialog


COffsetDatesDlg::COffsetDatesDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COffsetDatesDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(COffsetDatesDlg)
	m_bOffsetSubtasks = FALSE;
	//}}AFX_DATA_INIT

	// restore state
	CPreferences prefs;

	m_bOffsetStartDate = prefs.GetProfileInt("OffsetDates", "StartDate", FALSE);
	m_bOffsetDueDate = prefs.GetProfileInt("OffsetDates", "DueDate", FALSE);
	m_bOffsetDoneDate = prefs.GetProfileInt("OffsetDates", "DoneDate", FALSE);
	m_bForward = prefs.GetProfileInt("OffsetDates", "Forward", 1);
	m_nOffsetBy = prefs.GetProfileInt("OffsetDates", "Amount", 1);
	m_nOffsetByUnits = prefs.GetProfileInt("OffsetDates", "AmountUnits", 0);
	m_bOffsetSubtasks = prefs.GetProfileInt("OffsetDates", "Subtasks", 1);
}


void COffsetDatesDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COffsetDatesDlg)
	DDX_Check(pDX, IDC_OFFSETSTARTDATE, m_bOffsetStartDate);
	DDX_Check(pDX, IDC_OFFSETDUEDATE, m_bOffsetDueDate);
	DDX_Check(pDX, IDC_OFFSETDONEDATE, m_bOffsetDoneDate);
	DDX_CBIndex(pDX, IDC_DIRECTION, m_bForward);
	DDX_Text(pDX, IDC_BY, m_nOffsetBy);
	DDX_CBIndex(pDX, IDC_BYUNITS, m_nOffsetByUnits);
	DDX_Check(pDX, IDC_OFFSETSUBTASKS, m_bOffsetSubtasks);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COffsetDatesDlg, CDialog)
	//{{AFX_MSG_MAP(COffsetDatesDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COffsetDatesDlg message handlers

DWORD COffsetDatesDlg::GetOffsetWhat() const
{
	DWORD dwWhat = 0;

	if (m_bOffsetStartDate)
		dwWhat |= ODD_STARTDATE;

	if (m_bOffsetDueDate)
		dwWhat |= ODD_DUEDATE;

	if (m_bOffsetDoneDate)
		dwWhat |= ODD_DONEDATE;

	return dwWhat;
}

int COffsetDatesDlg::GetOffsetAmount(ODD_UNITS& nUnits) const
{
	nUnits = (ODD_UNITS)m_nOffsetByUnits;

	return (m_bForward ? m_nOffsetBy : -m_nOffsetBy);
}

void COffsetDatesDlg::OnOK()
{
	CDialog::OnOK();

	// save state
	CPreferences prefs;

	prefs.WriteProfileInt("OffsetDates", "StartDate", m_bOffsetStartDate);
	prefs.WriteProfileInt("OffsetDates", "DueDate", m_bOffsetDueDate);
	prefs.WriteProfileInt("OffsetDates", "DoneDate", m_bOffsetDoneDate);
	prefs.WriteProfileInt("OffsetDates", "Forward", m_bForward);
	prefs.WriteProfileInt("OffsetDates", "Amount", m_nOffsetBy);
	prefs.WriteProfileInt("OffsetDates", "AmountUnits", m_nOffsetByUnits);
	prefs.WriteProfileInt("OffsetDates", "Subtasks", m_bOffsetSubtasks);
}

