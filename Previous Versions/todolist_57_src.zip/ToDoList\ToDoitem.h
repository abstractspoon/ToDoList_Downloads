// ToDoitem.h: interface for the CToDoitem class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TODOITEM_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_)
#define AFX_TODOITEM_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "tdcstruct.h"
#include <afxtempl.h>
#include "..\3rdparty\fixalloc.h" 

class TODOITEM
{
public:
	TODOITEM(LPCTSTR szTitle, LPCTSTR szComments = NULL); 
	TODOITEM(); 
	TODOITEM(const TODOITEM& tdi); 
	TODOITEM(const TODOITEM* pTDI); 
	
	const TODOITEM& operator=(const TODOITEM& tdi); 

	BOOL HasLastMod() const;
	BOOL HasCreation() const;
	BOOL HasStart() const;
	BOOL HasDue() const;
	BOOL HasDueTime() const;
	BOOL IsDone() const;
	
	void ClearStart();
	void ClearDue();
	void ClearDone();
	
	BOOL IsDue() const;
	BOOL IsDue(const COleDateTime& dateDueBy) const;
	
	void SetModified();
	void ResetCalcs() const; 

	CString GetFirstCategory() const;
	CString GetFirstAllocTo() const;
	CString GetFirstDependency() const;

	BOOL GetNextOccurence(COleDateTime& dtNext) const;
	BOOL IsRecentlyEdited(const COleDateTimeSpan& dtSpan = 1.0 / 24.0) const; // 1 hour default

	COleDateTimeSpan GetRemainingDueTime() const; // in days

	static COleDateTimeSpan GetRemainingDueTime(const COleDateTime& date); // in days
	static BOOL HasDueTime(const COleDateTime& date);
	static void ParseTaskLink(const CString& sLink, DWORD& dwTaskID, CString& sFile);
	static CString MakeTaskLink(DWORD dwTaskID, const CString& sFile = "");

	//  ------------------------------------------
	
	CString sTitle;
	CString sComments, sCustomComments;
	CString sCommentsTypeID;
	COLORREF color;
	COleDateTime dateStart, dateDue, dateDone, dateCreated;
	int nPriority;
	double dCost;
	CStringArray aAllocTo;
	CString sAllocBy;
	CString sStatus;
	CStringArray aCategories;
	CString sCreatedBy;
	int nPercentDone;
	CString sFileRefPath;
	double dTimeEstimate, dTimeSpent;
	int nTimeEstUnits, nTimeSpentUnits;
	COleDateTime tLastMod;
	BOOL bFlagged;
	int nRisk;
	CString sExternalID;
	CStringArray aDependencies;
	TDIRECURRENCE trRecurrence;
	CString sVersion;
	
	// cached calculations for drawing optimization
	// mutable so that they can be updated in const methods
	mutable int nCalcPriority;
	mutable int nCalcPriorityIncDue;
	mutable int nCalcPercent;
	mutable int nCalcRisk;
	mutable double dCalcTimeEstimate, dCalcTimeSpent;
	mutable double dCalcCost;
	mutable COleDateTime dateEarliestDue;
	mutable BOOL bGoodAsDone, bDue;
	mutable int nSubtasksCount, nSubtasksDone;
	
	DECLARE_FIXED_ALLOC(TODOITEM);
};

class TODOSTRUCTURE
{
public:
	TODOSTRUCTURE() : m_dwID(0), m_pTDSParent(NULL) {}
	TODOSTRUCTURE(DWORD dwID);
	TODOSTRUCTURE(const TODOSTRUCTURE& tds);
	~TODOSTRUCTURE();

	const TODOSTRUCTURE& operator=(const TODOSTRUCTURE& tds); 

	DWORD GetTaskID() const { return m_dwID; }
	DWORD GetSubTaskID(int nPos) const;

	int GetSubTaskPosition(DWORD dwID) const;
	int GetPosition() const;

	TODOSTRUCTURE* GetParentTask() const;
	TODOSTRUCTURE* GetParentTask(DWORD dwID) const;
	DWORD GetParentTaskID() const;
	DWORD GetParentTaskID(DWORD dwID) const;

	BOOL ParentIsRoot() const { return (GetParentTaskID() == 0); }
	BOOL IsRoot() const { return (GetTaskID() == 0); }

	DWORD GetPreviousSubTaskID(DWORD dwID) const;
	DWORD GetPreviousSubTaskID(int nPos);

	int GetSubTaskCount() const { return m_aSubTasks.GetSize(); }
	BOOL HasSubTasks() const { return GetSubTaskCount() > 0; }

	TODOSTRUCTURE* GetSubTask(int nPos) const;
	
	BOOL AddSubTask(DWORD dwID);
	BOOL InsertSubTask(const TODOSTRUCTURE& tds, int nPos);
	BOOL InsertSubTask(DWORD dwID, int nPos);

	BOOL DeleteSubTask(DWORD dwID);
	BOOL DeleteSubTask(int nPos);
	void DeleteAll() { CleanUp(); }

	int MoveSubTask(int nPos, TODOSTRUCTURE* pTDSDestParent, int nDestPos);

	BOOL FindSubTask(DWORD dwID, TODOSTRUCTURE*& pTDSParent, int& nPos) const;
	TODOSTRUCTURE* FindSubTask(DWORD dwID) const;

protected:
	DWORD m_dwID;
	TODOSTRUCTURE* m_pTDSParent;
	CArray<TODOSTRUCTURE*, TODOSTRUCTURE*&> m_aSubTasks; 

protected:
	void CleanUp();
	BOOL InsertSubTask(TODOSTRUCTURE* pTDS, int nPos);
};


#endif // !defined(AFX_TODOITEM_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_)
