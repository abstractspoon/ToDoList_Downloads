// xmlfileex.h: interface for the CXmlFileEx class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_XMLFILEEX_H__C7DFA5B5_2B36_4D63_942C_9054EF4240CB__INCLUDED_)
#define AFX_XMLFILEEX_H__C7DFA5B5_2B36_4D63_942C_9054EF4240CB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "XmlFile.h"

class IEncryption;

enum
{
	XFL_NOENCRYPTIONDLL	   = XFL_LAST - 1,
	XFL_UNKNOWNENCRYPTION	= XFL_LAST - 2,
};

class CXmlFileEx : public CXmlFile  
{
public:
	CXmlFileEx(LPCTSTR szRootItemName = NULL, LPCTSTR szPassword = NULL);
	virtual ~CXmlFileEx();
	
	void SetPassword(LPCTSTR szPassword) { m_sPassword = szPassword; }
	CString GetPassword() { return m_sPassword; }
	
	// allows for selective decrypting
	BOOL Load(LPCTSTR szFilePath, LPCTSTR szRootItemName = NULL, IXmlParse* pCallback = NULL, BOOL bDecrypt = TRUE);
	BOOL Open(LPCTSTR szFilePath, XF_OPEN nOpenFlags, BOOL bDecrypt = TRUE);
	virtual BOOL LoadEx(LPCTSTR szRootItemName = NULL, IXmlParse* pCallback = NULL);
	
	// call before standard save
	virtual BOOL Encrypt(LPCTSTR szPassword = NULL); 
	virtual BOOL Decrypt(LPCTSTR szPassword = NULL); 
	static BOOL CanEncrypt(); // false if encryptor dll cannot be loaded
	
	static void SetUIStrings(UINT nIDPasswordExplanation, 
							 UINT nIDDecryptFailed);

protected:
	IEncryption* m_pEncryptor;
	CString m_sPassword;
	BOOL m_bDecrypt;

	static CString s_sPasswordExplanation, s_sDecryptFailed;

protected:
	BOOL Decrypt(LPCTSTR szInput, CString& sOutput, LPCTSTR szPassword);
	BOOL InitEncryptor();
	BOOL IsEncrypted();
	CXmlItem* GetEncryptedBlock();
	
};

#endif // !defined(AFX_XMLFILEEX_H__C7DFA5B5_2B36_4D63_942C_9054EF4240CB__INCLUDED_)
